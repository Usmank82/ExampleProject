﻿using System.Data.Entity;

namespace ExampleWebServer.Context
{
    public partial class ExampleContext : DbContext
    {
        public bool LogContext { get; set; }
        private readonly string _connectionString;
        public ExampleContext(string connectionString)
        {
            _connectionString = connectionString;
            LogContext = true;
        }
    }
}
