﻿using ExampleWebServer.Context;
using System;

namespace ExampleWebServer.Logging
{
    public class BaseLogger
    {
        private static ExampleContext _logContext;
        public static ExampleContext LogContext
        {
            get
            {
                if(_logContext==null)
                {
                    _logContext = new ExampleContext("Data Source=54.213.195.209;Initial Catalog=Example;User ID=example;Password=example");
                }
                return _logContext;
            }
        }
        public virtual void LogMessage(string message, object parameters)
        { }
        public static void LogException(int userId, string logEvent, Exception exception)
        {
            BaseLogger b = new BaseLogger();
            b.LogMessage(exception.Message,
                new
                {
                    Level = "Error",
                    Exception = "Error Saving Record",
                    UserId = userId
                });
        }
    }
}
